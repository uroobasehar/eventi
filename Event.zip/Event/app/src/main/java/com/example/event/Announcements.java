package com.example.event;

import androidx.appcompat.app.AppCompatActivity;

public class Announcements extends AppCompatActivity {
}