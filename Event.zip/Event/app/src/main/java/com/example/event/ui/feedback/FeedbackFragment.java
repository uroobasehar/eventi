package com.example.event.ui.feedback;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.example.event.Feedback;
import com.example.event.R;
import com.example.event.Student;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FeedbackFragment extends Fragment {
    private FirebaseDatabase mDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference mDatabaseReference = mDatabase.getReference();
    private FeedbackViewModel feedbackViewModel;
    private DatabaseReference nRef = mDatabaseReference.getRef();
    ArrayAdapter<CharSequence> adapter;

    Spinner dropdown;
    RatingBar rating;
    Button btn;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        feedbackViewModel =
                new ViewModelProvider(this, new ViewModelProvider.NewInstanceFactory()).get(FeedbackViewModel.class);

        View root = inflater.inflate(R.layout.fragment_feedback, container, false);

        return root;
    }
    public void onViewCreated(View view, Bundle savedInstanceState) {
        rating = getActivity().findViewById(R.id.ratingBar);
        btn = getActivity().findViewById(R.id.btn_feedback);

        dropdown = getActivity().findViewById(R.id.spinner2);
// Create an ArrayAdapter using the string array and a default spinner layout
        adapter = ArrayAdapter.createFromResource(getActivity(),
                R.array.Events, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        dropdown.setAdapter(adapter);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Feedback fb = new Feedback(dropdown.getSelectedItem().toString(), rating.getRating()+"");
                mDatabaseReference = mDatabase.getReference().child("Feedback");
                nRef= mDatabaseReference.child(dropdown.getSelectedItem().toString());

                nRef.setValue(fb);
                nRef.push();
                Toast.makeText(getActivity(), "Feedback Submitted Successfully! Thanks.", Toast.LENGTH_SHORT).show();

            }
        });
    }
}