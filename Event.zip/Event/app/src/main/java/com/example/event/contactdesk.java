package com.example.event;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.event.ui.contactdesk.ContactdeskFragment;

public class contactdesk extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contactdesk_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, ContactdeskFragment.newInstance())
                    .commitNow();
        }
    }
}