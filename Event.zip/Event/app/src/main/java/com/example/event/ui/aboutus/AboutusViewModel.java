package com.example.event.ui.aboutus;

import androidx.lifecycle.ViewModel;

public class AboutusViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
