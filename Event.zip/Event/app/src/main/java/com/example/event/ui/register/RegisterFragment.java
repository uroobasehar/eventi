package com.example.event.ui.register;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.event.R;
import com.example.event.Student;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterFragment extends Fragment {

    private RegisterViewModel  registerViewModel;

    EditText _programText;
    EditText _nameText;
    EditText _emailText;
    EditText _mobileText;
    EditText _semesterText;
    EditText _sapText;
    Button _signupButton;
    ArrayAdapter<CharSequence> adapter;
    Spinner dropdown;
    private FirebaseDatabase mDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference mDatabaseReference = mDatabase.getReference();
    private DatabaseReference nRef = mDatabaseReference.getRef();
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        registerViewModel =
                new ViewModelProvider(this, new ViewModelProvider.NewInstanceFactory()).get(RegisterViewModel.class);
        View root = inflater.inflate(R.layout.fragment_register, container, false);
       /* String [] values =
                {"Hult Prize","Student Day","Pace"};
        Spinner spinner = (Spinner) root.findViewById(R.id.spinner);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this.getActivity(), android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(adapter); */
        return root;
    }
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
         dropdown = getActivity().findViewById(R.id.spinner1);
// Create an ArrayAdapter using the string array and a default spinner layout
         adapter = ArrayAdapter.createFromResource(getActivity(),
                R.array.Events, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        dropdown.setAdapter(adapter);

        _programText = getActivity().findViewById(R.id.input_program);
        _nameText = getActivity().findViewById(R.id.input_name);
        _mobileText = getActivity().findViewById(R.id.input_mobile);
        _semesterText = getActivity().findViewById(R.id.input_semster);
        _sapText = getActivity().findViewById(R.id.input_sap);
        _emailText = getActivity().findViewById(R.id.input_email);
        _signupButton = getActivity().findViewById(R.id.btn_signup);
        _signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Student student = new Student(_nameText.getText().toString(), _programText.getText().toString(),  _emailText.getText().toString(),Integer.parseInt(_semesterText.getText().toString()) , Integer.parseInt(_sapText.getText().toString()),  _mobileText.getText().toString(),dropdown.getSelectedItem().toString());
if(validate()) {
    mDatabaseReference = mDatabase.getReference().child("Student");
    nRef = mDatabaseReference.child(_sapText.getText().toString());
    nRef.setValue(student);
    nRef.push();
    Toast.makeText(getActivity(), "Student Registered Successfully! Thanks.", Toast.LENGTH_SHORT).show();
}
            }
        });
    }
    public static boolean
    onlyDigits(String str, int n)
    {

        for (int i = 0; i < n; i++) {


            if (str.charAt(i) >= '0'
                    && str.charAt(i) <= '9') {
                return true;
            }
            else {
                return false;
            }
        }
        return false;
    }
    public boolean validate() {
        boolean valid = true;

        String name = _nameText.getText().toString();
        String program = _programText.getText().toString();
        String email = _emailText.getText().toString();
        String mobile = _mobileText.getText().toString();
        String semester = _semesterText.getText().toString();
        String sap = _sapText.getText().toString();

        if (name.isEmpty() ) {
            _nameText.setError("Enter a valid name");
            valid = false;
        } else {
            _nameText.setError(null);
        }

        if (program.isEmpty()) {
            _programText.setError("Enter valid program");
            valid = false;
        } else {
            _programText.setError(null);
        }


        if (email.isEmpty() /*|| !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()*/) {
            _emailText.setError("enter a valid email address");
            valid = false;
        } else {
            _emailText.setError(null);
        }

        if ( !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            _emailText.setError("enter a valid email address");
            valid = false;
        }

        if (mobile.isEmpty() /*|| mobile.length()!=11*/) {
            _mobileText.setError("This field cannot be empty");
            valid = false;
        } else {
            _mobileText.setError(null);
        }
        if ( mobile.length()!=11) {
            _mobileText.setError("Enter Valid Mobile Number");
            valid = false;
        }

        if (semester.isEmpty()  /*|| ((Integer.parseInt(semester))>10) || ((Integer.parseInt(semester))<1)*/) {
            _semesterText.setError("Invalid Semester");
            valid = false;
        } else {
            _semesterText.setError(null);
        }

        if (((Integer.parseInt(semester))>10) || ((Integer.parseInt(semester))<1)) {
            _semesterText.setError("Invalid Semester (Must range btween 1-10");
            valid = false;
        }

        if (sap.isEmpty() ) {
            _sapText.setError("Invalid SAP");
            valid = false;
        } else {
            _sapText.setError(null);
        }




        return valid;
    }
}