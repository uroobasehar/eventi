package com.example.event;

public class Feedback {
    String event;
    String rating;

    public Feedback(String event, String rating) {
        this.event = event;
        this.rating = rating;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }
}

