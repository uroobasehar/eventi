package com.example.event.ui.Announcements;

import androidx.lifecycle.ViewModel;

public class announcements extends ViewModel {
    // TODO: Implement the ViewModel
}