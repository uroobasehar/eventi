package com.example.event.ui.contactdesk;

import androidx.lifecycle.ViewModel;

public class contactdeskViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}