package com.example.event.ui.contactus;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.example.event.R;
import com.example.event.contactdesk;

public class ContactusFragment extends Fragment {

    private ContactusViewModel mViewModel;

    public static ContactusFragment newInstance() {
        return new ContactusFragment();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.contactus_fragment, container, false);
        Button button = (Button) root.findViewById(R.id.buttona);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(), contactdesk.class);
                startActivity(intent);

            }
        });
        return root;
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(ContactusViewModel.class);
        // TODO: Use the ViewModel
    }
    public void contactdesk(View view) {
        Intent intent = new Intent(getActivity(), contactdesk.class);
        startActivity(intent);
    }



}
