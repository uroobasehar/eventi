package com.example.event.ui.contactus;

import androidx.lifecycle.ViewModel;

public class ContactusViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
