package com.example.event;

public class Student {
    private String name;
    private String program;
    private String email;
    private int semester;
    private int sapId;
    private String mobile;
    private String event;

    public Student(String name, String program, String email, int semester, int sapId, String mobile, String event) {
        this.name = name;
        this.program = program;
        this.email = email;
        this.semester = semester;
        this.sapId = sapId;
        this.mobile = mobile;
        this.event = event;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public Student(String name, String program, String email, int semester, int sapId, String mobile) {
        this.name = name;
        this.program = program;
        this.email = email;
        this.semester = semester;
        this.sapId = sapId;
        this.mobile = mobile;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getProgram() {
        return program;
    }

    public void setProgram(String program) {
        this.program = program;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }

    public int getSapId() {
        return sapId;
    }

    public void setSapId(int sapId) {
        this.sapId = sapId;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
