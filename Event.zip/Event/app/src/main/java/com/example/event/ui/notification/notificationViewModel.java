package com.example.event.ui.notification;

import androidx.lifecycle.ViewModel;

public class notificationViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}